package java.org.usuario;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
public enum Resultado
{
	ganadas, perdidas, abandonadas;
}
