!/bin/bash
clear

mvn embedded-glassfish:run
