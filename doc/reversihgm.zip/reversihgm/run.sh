!/bin/bash
clear

mvn package embedded-glassfish:run
