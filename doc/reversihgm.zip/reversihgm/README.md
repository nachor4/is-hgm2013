Ejemplo WebSocket
=================

Requisitos:
- Maven
- Java EE7


El ejemplo corre dentro del servidor GlassFish, pero este se configuró con un 
plugin "embebido" de glassfish que será descargado e instalado por MVN


Inciar el Server
================
- Para iniciar el server, ejecutar el archvo run.sh


Nota: En la primera ejecución se descargan todos los archivos de GlassFish. 
Esto puede demorar mucho tiempo dependiendo del tipo de conexion.

Ejecutar la App
===============
- Para correr el testing, ingresar en: http://localhost:8080/javaee7Sample/
- Para apagar el server escribir: x + intro 
